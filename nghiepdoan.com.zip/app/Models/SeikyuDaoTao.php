<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SeikyuDaoTao extends Model
{
    protected $table = 'seikyuvemaybayvatiendaotao';
}
