<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class NganHang extends Model
{
    protected $table = 'thongtinnganhang';
}
