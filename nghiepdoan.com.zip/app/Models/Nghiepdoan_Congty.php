<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Nghiepdoan_Congty extends Model
{
    protected $table = 'nghiepdoan_congty';
}
