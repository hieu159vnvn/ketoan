<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class NghiepDoan extends Model
{
    protected $table = 'nghiepdoan';
}
