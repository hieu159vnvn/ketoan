<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class HoaDonTienQuanLy extends Model
{
    protected $table = 'hoadontienquanly';
}
