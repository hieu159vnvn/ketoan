<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class XacNhanSeiKyu extends Model
{
    protected $table = 'xacnhanseikyu';
}
